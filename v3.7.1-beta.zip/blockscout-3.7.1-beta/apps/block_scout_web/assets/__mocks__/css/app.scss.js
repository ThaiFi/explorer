export default {
  primary: "#4786ff",
  secondary: "#ced4da"
}
