defmodule BlockScoutWeb.Admin.SessionView do
  use BlockScoutWeb, :view

  import BlockScoutWeb.AdminRouter.Helpers

  alias BlockScoutWeb.FormView
end
