defmodule BlockScoutWeb.PendingTransactionView do
  use BlockScoutWeb, :view

  @dialyzer :no_match
end
