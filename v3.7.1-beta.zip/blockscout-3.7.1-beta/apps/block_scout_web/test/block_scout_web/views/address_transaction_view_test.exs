defmodule BlockScoutWeb.AddressTransactionViewTest do
  use BlockScoutWeb.ConnCase, async: true

  doctest BlockScoutWeb.AddressTransactionView
end
