defmodule BlockScoutWeb.Tokens.ReadContractViewTest do
  use BlockScoutWeb.ConnCase, async: true
end
